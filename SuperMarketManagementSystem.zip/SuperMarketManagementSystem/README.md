project fully handcrafted and submitted  by Sriram.M to skcet as react mini-project
