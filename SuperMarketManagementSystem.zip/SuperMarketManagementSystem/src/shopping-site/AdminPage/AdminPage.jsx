import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import axios from 'axios';
import './AdminPage.css';

const AdminPage = () => {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    category: '',
    price: '',
    stock: '',
    image: '',
    rating: '',
    tags: '',
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [editingProductId, setEditingProductId] = useState(null);
  const [editedProduct, setEditedProduct] = useState({ 
    price: '', 
    description: '', 
    image: '', 
    rating: '', 
    tags: '' 
  });

  const navigate = useNavigate(); // Initialize the navigation function

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/products');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewProduct({ ...newProduct, [name]: value });
  };

  const handleFileChange = (e, isEditing = false) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      if (isEditing) {
        setEditedProduct({ ...editedProduct, image: reader.result });
      } else {
        setNewProduct({ ...newProduct, image: reader.result });
      }
    };
    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!newProduct.name || !newProduct.category || !newProduct.price || !newProduct.stock) {
      alert('Please fill in all required fields.');
      return;
    }

    const newProductData = {
      ...newProduct,
      price: parseFloat(newProduct.price),
      stock: parseInt(newProduct.stock, 10),
      rating: parseFloat(newProduct.rating),
      tags: newProduct.tags.split(',').map(tag => tag.trim()),
    };

    try {
      await axios.post('http://localhost:5000/api/products', newProductData);
      setNewProduct({
        name: '',
        description: '',
        category: '',
        price: '',
        stock: '',
        image: '',
        rating: '',
        tags: '',
      });
      fetchProducts();
      alert('Product added successfully!');
    } catch (error) {
      console.error('Error adding product:', error);
      alert('There was an error adding the product. Please try again.');
    }
  };

  const handleRemove = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/products/${id}`);
      fetchProducts();
    } catch (error) {
      console.error('Error removing product:', error);
    }
  };

  const handleEditClick = (product) => {
    setEditingProductId(product._id);
    setEditedProduct({
      price: product.price,
      description: product.description,
      image: product.image,
      rating: product.rating,
      tags: product.tags.join(', '),
    });
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditedProduct({ ...editedProduct, [name]: value });
  };

  const handleEditSubmit = async (id) => {
    try {
      const updatedProduct = {
        ...editedProduct,
        price: parseFloat(editedProduct.price),
        rating: parseFloat(editedProduct.rating),
        tags: editedProduct.tags.split(',').map(tag => tag.trim()),
      };
      await axios.put(`http://localhost:5000/api/products/${id}`, updatedProduct);
      setEditingProductId(null);
      fetchProducts();
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Function to handle navigation to the Pending Orders page
  const navigateToPendingOrders = () => {
    navigate('/pending-orders');
  };

  return (
    <div className="admin-container">
      <h1>Admin Page</h1>

      <button className="pending-orders-btn" onClick={navigateToPendingOrders}>
        Pending Orders
      </button> {/* Button to navigate to pending orders */}

      <div className="add-product-section">
        <h2>Add New Product</h2>
        <form className="add-product-form" onSubmit={handleSubmit}>
          {/* Form fields for adding a new product */}
          <div className="form-group">
            <label htmlFor="name">Product Name</label>
            <input
              id="name"
              type="text"
              name="name"
              value={newProduct.name}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="category">Category</label>
            <input
              id="category"
              type="text"
              name="category"
              value={newProduct.category}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="price">Price</label>
            <input
              id="price"
              type="number"
              name="price"
              value={newProduct.price}
              onChange={handleInputChange}
              step="0.01"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="stock">Stock</label>
            <input
              id="stock"
              type="number"
              name="stock"
              value={newProduct.stock}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="image">Product Image</label>
            <input
              id="image"
              type="file"
              name="image"
              onChange={handleFileChange}
              accept="image/*"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="rating">Rating</label>
            <input
              id="rating"
              type="number"
              name="rating"
              value={newProduct.rating}
              onChange={handleInputChange}
              step="0.1"
              min="0"
              max="5"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="tags">Tags</label>
            <input
              id="tags"
              type="text"
              name="tags"
              value={newProduct.tags}
              onChange={handleInputChange}
              placeholder="Comma-separated tags"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              name="description"
              value={newProduct.description}
              onChange={handleInputChange}
              required
            />
          </div>
          <button type="submit">Add Product</button>
        </form>
      </div>

      <div className="product-list-section">
        <h2>Product List</h2>
        <input
          type="text"
          className="search-bar"
          placeholder="Search products by name or category"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <div className="product-list">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <div key={product._id} className="product-card">
                <h3>{product.name}</h3>
                <img src={product.image} alt={product.name} />
                <p>Product ID: {product.productId}</p>
                <p>Category: {product.category}</p>
                <p>Price: ${product.price.toFixed(2)}</p>
                <p>Stock: {product.stock}</p>
                <p>Rating: {product.rating ? product.rating.toFixed(1) : 'N/A'}</p>
                <p>Tags: {product.tags.join(', ')}</p>

                {editingProductId === product._id ? (
                  <div className="edit-mode">
                    <input
                      type="number"
                      name="price"
                      value={editedProduct.price}
                      onChange={handleEditChange}
                      placeholder="Edit Price"
                    />
                    <textarea
                      name="description"
                      value={editedProduct.description}
                      onChange={handleEditChange}
                      placeholder="Edit Description"
                    />
                    <input
                      type="file"
                      name="image"
                      onChange={(e) => handleFileChange(e, true)}
                      accept="image/*"
                    />
                    <input
                      type="number"
                      name="rating"
                      value={editedProduct.rating}
                      onChange={handleEditChange}
                      step="0.1"
                      min="0"
                      max="5"
                    />
                    <input
                      type="text"
                      name="tags"
                      value={editedProduct.tags}
                      onChange={handleEditChange}
                      placeholder="Edit Tags"
                    />
                    <button onClick={() => handleEditSubmit(product._id)}>Save</button>
                    <button onClick={() => setEditingProductId(null)}>Cancel</button>
                  </div>
                ) : (
                  <>
                    <button onClick={() => handleEditClick(product)}>Edit</button>
                    <button onClick={() => handleRemove(product._id)}>Remove</button>
                  </>
                )}
              </div>
            ))
          ) : (
            <p>No products found.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
