import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './PendingOrders.css'; // Import the CSS file

const PendingOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/orders');
        setOrders(response.data);
      } catch (err) {
        console.error('Error fetching orders:', err);
        setError('Failed to fetch orders.');
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="pending-orders-container">
      <h1>All Orders</h1>
      {orders.length === 0 ? (
        <p>No orders available.</p>
      ) : (
        <ul className="orders-list">
          {orders.map((order) => (
            <li key={order._id} className="order-item">
              <h3>Order ID: {order._id}</h3>
              <div className="order-details">
                <div className="product-info">
                  <h4>Product: {order.product?.name}</h4>
                  <p>{order.product?.description}</p>
                  <p>Price: ${order.product?.price.toFixed(2)}</p>
                </div>
                <div className="delivery-info">
                  <h4>Delivery Address:</h4>
                  <p>{order.deliveryDetails?.name}</p>
                  <p>{order.deliveryDetails?.street}</p>
                  <p>{order.deliveryDetails?.city}, {order.deliveryDetails?.postalCode}</p>
                  <p>{order.deliveryDetails?.country}</p>
                  <p>Phone: {order.deliveryDetails?.phoneNumber}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default PendingOrdersPage;