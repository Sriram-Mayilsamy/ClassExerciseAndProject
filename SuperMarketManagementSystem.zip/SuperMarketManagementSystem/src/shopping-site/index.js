// Create this new file at: src/shopping-site/index.js

// Import all components from their respective folders
import AdminPage from './AdminPage/AdminPage';
import CheckoutPage from './CheckoutPage/CheckoutPage';
import CustomerPage from './CustomerPage/CustomerPage';
import PendingOrdersPage from './PendingOrdersPage/PendingOrdersPage';

// Export all components
export {
    AdminPage,
    CheckoutPage,
    CustomerPage,
    PendingOrdersPage
};