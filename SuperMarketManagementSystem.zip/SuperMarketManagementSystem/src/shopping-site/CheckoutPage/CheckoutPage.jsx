import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios'; // Import Axios for HTTP requests
import './CheckoutPage.css';

const CheckoutPage = () => {
  const { state } = useLocation(); // To get the product passed from CustomerPage
  const navigate = useNavigate();
  const product = state?.product; // Get product details from the state

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phoneNumber: '',
    street: '',
    city: '',
    postalCode: '',
    country: '',
  });

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const orderDetails = {
      product,
      deliveryDetails: formData,
    };

    try {
      // Make the POST request to your backend API
      const response = await axios.post('http://localhost:5000/api/orders', orderDetails);
      console.log('Order placed:', response.data);

      // After submitting, navigate to a success page or order confirmation page
      navigate('/order-confirmation', { state: { product, deliveryDetails: formData } });
    } catch (error) {
      console.error('Error placing the order:', error);
      // You might want to show an error message to the user here
    }
  };

  return (
    <div className="checkout-container">
      <h1 className="checkout-title">Checkout</h1>
      
      {product ? (
        <div className="product-summary">
          <h2>You're purchasing:</h2>
          <div className="product-info">
            <img src={product.image} alt={product.name} className="product-image" />
            <div className="product-details">
              <h3>{product.name}</h3>
              <p>{product.description}</p>
              <p className="product-price">Price: ${product.price.toFixed(2)}</p>
            </div>
          </div>
        </div>
      ) : (
        <p>No product selected for purchase.</p>
      )}

      <form className="address-form" onSubmit={handleSubmit}>
        <h2>Delivery Information</h2>

        <div className="form-group">
          <label htmlFor="name">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="phoneNumber">Phone Number</label>
          <input
            type="tel"
            id="phoneNumber"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="street">Street Address</label>
          <input
            type="text"
            id="street"
            name="street"
            value={formData.street}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="city">City</label>
          <input
            type="text"
            id="city"
            name="city"
            value={formData.city}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="postalCode">Postal Code</label>
          <input
            type="text"
            id="postalCode"
            name="postalCode"
            value={formData.postalCode}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="country">Country</label>
          <input
            type="text"
            id="country"
            name="country"
            value={formData.country}
            onChange={handleInputChange}
            required
          />
        </div>

        <button type="submit" className="submit-button">Place Order</button>
      </form>
    </div>
  );
};

export default CheckoutPage;
