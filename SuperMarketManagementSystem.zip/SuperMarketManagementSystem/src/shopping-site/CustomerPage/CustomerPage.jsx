// CustomerPage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // For navigation
import './CustomerPage.css';

const CustomerPage = () => {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate(); // Hook for navigation

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/products');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  // Function to handle buy/checkout
  const handleBuyNow = (product) => {
    // Redirect to checkout page with product details
    navigate('/checkout', { state: { product } });
  };

  return (
    <div className="shop-container">
      <header className="shop-header">
        <div className="header-content">
          <h1 className="shop-title">ShopEasy</h1>
          <nav className="shop-nav">
            <button className="nav-button">
              <i className="fas fa-search"></i>
            </button>
            <button className="nav-button">
              <i className="fas fa-shopping-cart"></i>
            </button>
            <button className="nav-button mobile-menu">
              <i className="fas fa-bars"></i>
            </button>
          </nav>
        </div>
      </header>

      <main className="shop-main">
        <h2 className="products-title">Our Products</h2>
        <div className="product-grid">
          {products.map((product) => (
            <div key={product._id} className="product-card">
              <div className="product-image-container">
                <img src={product.image} alt={product.name} className="product-image" />
              </div>
              <div className="product-details">
                <h3 className="product-name">{product.name}</h3>
                <p className="product-description">{product.description}</p>
                <div className="product-info">
                  <span className="product-price">${product.price.toFixed(2)}</span>
                  <span className="product-rating">Rating: {product.rating}/5</span>
                </div>
                <div className="product-tags">
                  {product.tags.map((tag, index) => (
                    <span key={index} className="product-tag">{tag}</span>
                  ))}
                </div>
                <button 
                  className="buy-button" 
                  onClick={() => handleBuyNow(product)}
                >
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      <footer className="shop-footer">
        <p>&copy; 2024 ShopEasy. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default CustomerPage;
