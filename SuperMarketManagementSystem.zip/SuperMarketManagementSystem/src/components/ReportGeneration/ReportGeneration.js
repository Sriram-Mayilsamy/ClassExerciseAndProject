import React, { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const ReportGeneration = () => {
  const [dateRange, setDateRange] = useState('month');
  const [reportType, setReportType] = useState('sales');

  // Sample data - replace with your actual data fetching logic
  const salesData = [
    { date: '2024-01', sales: 4000, orders: 240, profit: 1200 },
    { date: '2024-02', sales: 3000, orders: 198, profit: 900 },
    { date: '2024-03', sales: 5000, orders: 280, profit: 1500 },
    { date: '2024-04', sales: 2780, orders: 190, profit: 834 },
    { date: '2024-05', sales: 4890, orders: 290, profit: 1467 },
    { date: '2024-06', sales: 6390, orders: 310, profit: 1917 },
  ];

  const productData = [
    { name: 'Product A', sales: 1200, stock: 45 },
    { name: 'Product B', sales: 890, stock: 32 },
    { name: 'Product C', sales: 1700, stock: 68 },
    { name: 'Product D', sales: 560, stock: 12 },
    { name: 'Product E', sales: 990, stock: 24 },
  ];

  // Summary metrics calculation
  const totalSales = salesData.reduce((sum, item) => sum + item.sales, 0);
  const totalOrders = salesData.reduce((sum, item) => sum + item.orders, 0);
  const totalProfit = salesData.reduce((sum, item) => sum + item.profit, 0);

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Header Section */}
      <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>Report Generation</h1>
        
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          <select 
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            style={{
              padding: '8px 12px',
              border: '1px solid #ddd',
              borderRadius: '4px',
              backgroundColor: 'white'
            }}
          >
            <option value="week">Last Week</option>
            <option value="month">Last Month</option>
            <option value="quarter">Last Quarter</option>
            <option value="year">Last Year</option>
          </select>
          
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            style={{
              padding: '8px 12px',
              border: '1px solid #ddd',
              borderRadius: '4px',
              backgroundColor: 'white'
            }}
          >
            <option value="sales">Sales Report</option>
            <option value="inventory">Inventory Report</option>
            <option value="customers">Customer Report</option>
          </select>
          
          <button 
            style={{
              padding: '8px 16px',
              backgroundColor: '#2563eb',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
            onClick={() => console.log('Export clicked')}
          >
            Export Report
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', 
        gap: '20px',
        marginBottom: '20px' 
      }}>
        <div style={{ 
          padding: '20px', 
          backgroundColor: 'white', 
          borderRadius: '8px', 
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)' 
        }}>
          <h3 style={{ marginBottom: '10px', color: '#666' }}>Total Sales</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>${totalSales.toLocaleString()}</p>
        </div>
        <div style={{ 
          padding: '20px', 
          backgroundColor: 'white', 
          borderRadius: '8px', 
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)' 
        }}>
          <h3 style={{ marginBottom: '10px', color: '#666' }}>Total Orders</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{totalOrders.toLocaleString()}</p>
        </div>
        <div style={{ 
          padding: '20px', 
          backgroundColor: 'white', 
          borderRadius: '8px', 
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)' 
        }}>
          <h3 style={{ marginBottom: '10px', color: '#666' }}>Total Profit</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>${totalProfit.toLocaleString()}</p>
        </div>
      </div>

      {/* Sales Chart */}
      <div style={{ 
        backgroundColor: 'white', 
        padding: '20px', 
        borderRadius: '8px', 
        marginBottom: '20px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginBottom: '20px', fontSize: '18px', fontWeight: 'bold' }}>Sales Overview</h2>
        <div style={{ height: '400px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="sales" stroke="#2563eb" name="Sales ($)" />
              <Line type="monotone" dataKey="profit" stroke="#16a34a" name="Profit ($)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Product Performance */}
      <div style={{ 
        backgroundColor: 'white', 
        padding: '20px', 
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginBottom: '20px', fontSize: '18px', fontWeight: 'bold' }}>Product Performance</h2>
        <div style={{ height: '400px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={productData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sales" fill="#2563eb" name="Sales" />
              <Bar dataKey="stock" fill="#16a34a" name="Current Stock" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default ReportGeneration;