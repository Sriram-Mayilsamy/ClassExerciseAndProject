import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage/LoginPage';
import SignupPage from './components/SignupPage/SignupPage';
import SelectionPage from './components/SelectionPage/SelectionPage';
import Dashboard from './components/Dashboard/Dashboard';
import ProductCatalogue from './components/ProductCatalogue/ProductCatalogue';
import Sales from './components/Sales/Sales';
import PrivateRoute from './components/Firebase/PrivateRoute';
import { AuthProvider } from './components/Firebase/AuthContext';
import SalesReport from './components/ReportGeneration/ReportGeneration';

// Import Shopping Site components (correct paths)
import AdminPage from './shopping-site/AdminPage/AdminPage';
import CheckoutPage from './shopping-site/CheckoutPage/CheckoutPage';
import CustomerPage from './shopping-site/CustomerPage/CustomerPage';
import PendingOrdersPage from './shopping-site/PendingOrdersPage/PendingOrdersPage';

// Shopping site main component
const ShoppingMain = () => {
  return (
    <div>
      <Routes>
        <Route index element={<CustomerPage />} />
        <Route path="admin" element={<AdminPage />} />
        <Route path="checkout" element={<CheckoutPage />} />
        <Route path="pending-orders" element={<PendingOrdersPage />} />
      </Routes>
    </div>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="App">
          <Routes>
            {/* Authentication Routes */}
            <Route path="/" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />

            {/* Main Application Routes */}
            <Route
              path="/selection"
              element={
                <PrivateRoute>
                  <SelectionPage />
                </PrivateRoute>
              }
            />
            <Route
              path="/dashboard"
              element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              }
            />
            <Route
              path="/product-catalogue"
              element={
                <PrivateRoute>
                  <ProductCatalogue />
                </PrivateRoute>
              }
            />
            <Route
              path="/sales"
              element={
                <PrivateRoute>
                  <Sales />
                </PrivateRoute>
              }
            />
            <Route
  path="/report-generation"
  element={
    <PrivateRoute>
      <SalesReport />
    </PrivateRoute>
  }
/>

            {/* Shopping Site Routes */}
            <Route
              path="/shopping/*"
              element={
                <PrivateRoute>
                  <ShoppingMain />
                </PrivateRoute>
              }
            />
          </Routes>
        </div>
      </AuthProvider>
    </Router>
  );
}

export default App;
