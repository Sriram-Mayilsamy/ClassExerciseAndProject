const mongoose = require('mongoose');

// Order Schema
const orderSchema = new mongoose.Schema({
  product: {
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String },
    image: { type: String }
  },
  deliveryDetails: {
    name: { type: String, required: true },
    email: { type: String, required: true },
    phoneNumber: { type: String, required: true },
    street: { type: String, required: true },
    city: { type: String, required: true },
    postalCode: { type: String, required: true },
    country: { type: String, required: true }
  },
  orderDate: { type: Date, default: Date.now }
});

// Export the Order model
module.exports = mongoose.model('Order', orderSchema);
