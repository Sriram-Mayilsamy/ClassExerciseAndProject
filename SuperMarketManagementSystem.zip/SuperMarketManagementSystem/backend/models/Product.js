const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  productId: { type: String, required: true, unique: true }, // New field for product ID
  name: { type: String, required: true },
  description: { type: String, required: true },
  category: { type: String, required: true },
  price: { type: Number, required: true },
  stock: { type: Number, required: true },
  image: { type: String, required: true },
  rating: { type: Number, required: true },
  tags: [{ type: String }]
}, { 
  strict: false,
  collection: 'products'  // Ensure this matches the collection name in your database
});

const Product = mongoose.model('Product', productSchema);
module.exports = Product;
