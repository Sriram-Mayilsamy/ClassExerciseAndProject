const express = require('express');
const router = express.Router();
const Order = require('../models/Order');  // Import the Order model

// POST request to create a new order
router.post('/', async (req, res) => {
  try {
    const { product, deliveryDetails } = req.body;
    const newOrder = new Order({
      product,
      deliveryDetails,
      orderDate: new Date(),
    });

    await newOrder.save();
    res.status(201).json({ message: 'Order placed successfully!', order: newOrder });
  } catch (error) {
    res.status(500).json({ message: 'Failed to place order', error });
  }
});

// GET request to fetch all orders
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find();
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch orders', error });
  }
});

// GET request to fetch a single order by ID
router.get('/:id', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    res.status(200).json(order);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch the order', error });
  }
});

module.exports = router;
