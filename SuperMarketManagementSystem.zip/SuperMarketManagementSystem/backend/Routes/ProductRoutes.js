const express = require('express');
const Product = require('../models/Product');
const router = express.Router();

// Function to generate a unique 6-digit product ID
const generateProductId = async () => {
  const existingProduct = await Product.find().sort({ productId: -1 }).limit(1);
  let newId;

  if (existingProduct.length === 0) {
    newId = '100000'; // Starting from the first 6-digit ID
  } else {
    const lastId = existingProduct[0].productId;
    if (lastId && !isNaN(lastId)) {
      newId = (parseInt(lastId) + 1).toString().padStart(6, '0');
    } else {
      newId = '100000'; // Fallback if lastId is invalid
    }
  }

  return newId;
};

// GET: Fetch all products
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find().lean();
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching products', error: error.message });
  }
});

// POST: Create a new product
router.post('/products', async (req, res) => {
  try {
    const { name, description, category, price, stock, image, rating, tags } = req.body;

    // Generate a unique product ID
    const productId = await generateProductId();

    // Create a new product document
    const newProduct = new Product({
      productId,
      name,
      description,
      category,
      price,
      stock,
      image,
      rating,
      tags
    });

    // Save the product to the database
    const savedProduct = await newProduct.save();
    res.status(201).json(savedProduct);
  } catch (error) {
    res.status(500).json({ message: 'Error creating product', error: error.message });
  }
});

// PUT: Edit a product by ID
router.put('/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    const updatedProduct = await Product.findByIdAndUpdate(id, updatedData, {
      new: true,
      runValidators: true,
    });

    if (!updatedProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.status(200).json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: 'Error updating product', error: error.message });
  }
});

// DELETE: Remove a product by ID
router.delete('/products/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const deletedProduct = await Product.findByIdAndDelete(id);

    if (!deletedProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.status(200).json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting product', error: error.message });
  }
});

module.exports = router;